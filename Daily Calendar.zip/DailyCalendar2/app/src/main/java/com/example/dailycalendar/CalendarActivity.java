package com.example.dailycalendar;
import android.content.Intent;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.Button;
import android.widget.Toast;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CalendarActivity extends AppCompatActivity{
    private CalendarView calendarView;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        calendarView = findViewById(R.id.calendarView);
        Button btnSelectDate = findViewById(R.id.btnSelectDate);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
        });

        btnSelectDate.setOnClickListener(v -> {
            if (selectedDate != null) {
                Intent intent = new Intent(CalendarActivity.this, MainActivity.class);
                intent.putExtra("selectedDate", selectedDate);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show();
            }
        });
//        setContentView(R.layout.activity_calendar);
//
//        // Register context menu for a TextView (representing an event)
//        TextView eventTextView = findViewById(R.id.event_text_view);
//        registerForContextMenu(eventTextView);
//
//        // Set up popup menu button
//        Button popupButton = findViewById(R.id.popup_button);
//        popupButton.setOnClickListener(v -> {
//            PopupMenu popupMenu = new PopupMenu(CalendarActivity.this, v, Gravity.END);
//            popupMenu.getMenuInflater().inflate(R.menu.popup_menu_calendar, popupMenu.getMenu());
//            popupMenu.setOnMenuItemClickListener(item -> {
//                int id = item.getItemId();
//                if (id == R.id.popup_add_event) {
//                    Toast.makeText(CalendarActivity.this, "Add Event selected", Toast.LENGTH_SHORT).show();
//                    return true;
//                } else if (id == R.id.popup_view_event) {
//                    Toast.makeText(CalendarActivity.this, "View Event selected", Toast.LENGTH_SHORT).show();
//                    return true;
//                }
//                return false;
//            });
//            popupMenu.show();
        };
    }




//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.menu_calendar, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        int id = item.getItemId();
//        if (id == R.id.action_add_event) {
//            Toast.makeText(this, "Hello, I am in addEvent", Toast.LENGTH_SHORT).show();
//            return true;
//        } else if (id == R.id.action_view_events) {
//            Toast.makeText(this, "Hello, I am in viewEvents", Toast.LENGTH_SHORT).show();
//            return true;
//        } else if (id == R.id.action_filter_events) {
//            Toast.makeText(this, "Hello, I am in filterEvents", Toast.LENGTH_SHORT).show();
//            return true;
//        } else if (id == R.id.action_sort_events) {
//            Toast.makeText(this, "Hello, I am in sortEvents", Toast.LENGTH_SHORT).show();
//            return true;
//        } else if (id == R.id.action_settings) {
//            Toast.makeText(this, "Hello, I am in openSettings", Toast.LENGTH_SHORT).show();
//            return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }
//
//    @Override
//    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
//        super.onCreateContextMenu(menu, v, menuInfo);
//        getMenuInflater().inflate(R.menu.context_menu_calendar, menu);
//    }
//
//    @Override
//    public boolean onContextItemSelected(MenuItem item) {
//        int id = item.getItemId();
//        if (id == R.id.context_edit_event) {
//            Toast.makeText(this, "Edit Event selected", Toast.LENGTH_SHORT).show();
//            return true;
//        } else if (id == R.id.context_delete_event) {
//            Toast.makeText(this, "Delete Event selected", Toast.LENGTH_SHORT).show();
//            return true;
//        }
//        return super.onContextItemSelected(item);
//    }


